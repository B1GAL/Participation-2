﻿using System;

namespace participation_2_4_2021
{
    class Program
    {
        static void Main(string[] args)
        {
               const double SUPER_NUMBER = 3.1415;

            //SUPER_NUMBER = 69;

        }
    }
}
